package androidx.activity;

interface Cancellable {
    void cancel();
}
