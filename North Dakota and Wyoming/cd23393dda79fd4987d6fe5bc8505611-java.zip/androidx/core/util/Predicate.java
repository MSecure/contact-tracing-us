package androidx.core.util;

public interface Predicate<T> {
    boolean test(T t);
}
